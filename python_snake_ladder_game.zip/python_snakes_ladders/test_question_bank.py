import json
from pathlib import Path
bank = json.loads((Path(__file__).parent / "questions.json").read_text(encoding="utf-8"))
assert len(bank) == 150, f"expected 150 questions, found {len(bank)}"
assert len({q["question"] for q in bank}) == 150, "question text should be unique"
for q in bank:
    assert len(q["choices"]) == 4
    assert 0 <= q["answer"] < 4
    assert q["topic"] and q["explanation"]
print("Question bank OK: 150 unique questions.")
